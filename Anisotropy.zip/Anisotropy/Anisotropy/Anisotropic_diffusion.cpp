#include <iostream>
#include <opencv2/opencv.hpp>

#include "Anisotropic_diffusion.h"

using namespace std;
using namespace cv;

void anisotropic_diffusion(Mat &out, Mat &in, int k, float lambda) {
	int i, j;
	int iter = 20;
	int nRow = in.rows, nCol = in.cols;
	float ei, si, wi, ni;
	float ce, cs, cw, cn;

	Mat tmp = in.clone();
	uchar *pin = in.data;
	uchar *ptmp = tmp.data;
	uchar *pout = out.data;

	for (int n = 0; n < iter; n++)
	{
		for (i = 1; i < nRow - 1; i++)
			for (j = 1; j < nCol - 1; j++)
			{
				float cur = ptmp[i*nCol + j];
				ei = ptmp[(i - 1)*nCol + j] - cur;
				si = ptmp[i*nCol + j + 1] - cur;
				wi = ptmp[(i + 1)*nCol + j] - cur;
				ni = ptmp[i*nCol + j - 1] - cur;

				ce = exp(-ei*ei / (k*k));
				cs = exp(-si*si / (k*k));
				cw = exp(-wi*wi / (k*k));
				cn = exp(-ni*ni / (k*k));

				//pout[i*nCol + j] = cur + lambda*(ce*ei + cs*si + cw*wi + cn*ni);
				pout[i*nCol + j] = cur + lambda*(ce + cs + cw + cn);
			}
		out.copyTo(tmp);
	}
}