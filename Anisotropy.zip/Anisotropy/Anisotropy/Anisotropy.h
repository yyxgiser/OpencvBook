#pragma once
#ifndef _Anisotropy_h_
#define _Anisotropy_h_

#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

  //float k = 15;
  //float lambda = 0.25;



//  ������ϵ������
void anisotropy(Mat &image, Mat &result);





#endif // _Anisotropy_h_