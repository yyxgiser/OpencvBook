#pragma once
#ifndef _Anisotropy_diffusion_h_
#define _Anisotropic_diffusion_h_

#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

//float k = 15;
//float lambda = 0.25;

void anisotropic_diffusion(Mat &out, Mat &in, int k, float lambda);

#endif //_Anisotropic_diffusion_h_
