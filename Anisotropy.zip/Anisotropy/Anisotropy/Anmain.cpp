//         ʵ�ָ������Ե�ͼ����ɢ  ʵ������
//         ���ߣ�Ҧ����
//         ʱ�䣺2019.11.9

#include <iostream>
#include <opencv2/opencv.hpp>

#include "Anisotropy.h"
#include "Anisotropic_diffusion.h"

using namespace std;
using namespace cv;

char* create = "Theashold";
char* ThName = "result01";
int Theashold_value = 15;
int Theashold_max = 80;
void threshold_Callback(int, void*);
double lambda = 2.5;
float N = 20;

Mat src;

int main()
{
	src = imread("D:\\Code\\ImagesDataes\\data\\home.jpg", 1);
	if (!src.data)
	{
		printf("Could not find load image. \n");
		return -1;
	}
	namedWindow("input image", CV_WINDOW_AUTOSIZE);
	imshow("input image", src);
	cout << "���ߣ�yyx" << "       " << "ʱ�䣺2019.11.9" << endl;

	double t01 = getTickCount();
	vector<Mat> mv;
	vector<Mat> results;
	split(src, mv);
	for (int n = 0; n < mv.size(); n++) {
		Mat m = Mat::zeros(src.size(), CV_32FC1);
		mv[n].convertTo(m, CV_32FC1);
		results.push_back(m);
	}
	int w = src.cols;
	int h = src.rows;
	Mat copy = Mat::zeros(src.size(), CV_32FC1);

	for (int i = 0; i < N; i++) {
		anisotropy(results[0], copy);
		copy.copyTo(results[0]);
		anisotropy(results[1], copy);
		copy.copyTo(results[1]);
		anisotropy(results[2], copy);
		copy.copyTo(results[2]);
	}
	normalize(results[0], results[0], 0, 255, NORM_MINMAX);  //normalize��һ������
	normalize(results[1], results[1], 0, 255, NORM_MINMAX);
	normalize(results[2], results[2], 0, 255, NORM_MINMAX);
	results[0].convertTo(mv[0], CV_8UC1);
	results[1].convertTo(mv[1], CV_8UC1);
	results[2].convertTo(mv[2], CV_8UC1);
	double t02 = getTickCount();

	//************************
	//  1 ��ͼ�����ƽ��
	//************************
	Mat output;
	merge(mv, output);            //�������ͨ��ͼ��ϳ�һ����ͨ��ͼ��
	cout << " ͼ����ɢ���1�����ѵ�ʱ�䣺  " << (t02 - t01) / getTickFrequency() * 1000 << " s " << endl;
	imshow(ThName, output);
	imwrite("result01.jpg", output);

	//************************
	//  2 ��ͼ�����ƽ��
	//************************

	namedWindow("result02", CV_WINDOW_AUTOSIZE);
	createTrackbar(create, "result02", &Theashold_value, Theashold_max, threshold_Callback);
	threshold_Callback(0,0);
	//Mat dst2 = src.clone();   // �����¡
	//double t1 = getTickCount();
	//anisotropic_diffusion(dst2, src, Theashold_value, lambda);
	//double t2 = getTickCount();
	//cout <<  " ͼ����ɢ���2�����ѵ�ʱ�䣺  "  << (t2 - t1) / getTickFrequency() * 1000 <<" s "<< endl;
	//imshow("result02", dst2);
	//imwrite("result02.jpg", dst2);


	waitKey(0);
	return 0;
}

void threshold_Callback(int, void*) {
	Mat dst2 = src.clone();   // �����¡
	double t1 = getTickCount();
	anisotropic_diffusion(dst2, src, Theashold_value, lambda);
	imshow("result02", dst2);
	double t2 = getTickCount();
	cout << " ͼ����ɢ���2�����ѵ�ʱ�䣺  " << (t2 - t1) / getTickFrequency() * 1000 << " s " << endl;
	cout<<"��ֵ K �Ĳ�ֵͬ��"<< Theashold_value<<endl;
	return;
}