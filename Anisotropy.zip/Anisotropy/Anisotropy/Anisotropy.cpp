#include <iostream>
#include <opencv2/opencv.hpp>

#include "Anisotropy.h"

using namespace std;
using namespace cv;

double  k = 15;

//  ������ϵ������
void anisotropy(Mat &image, Mat &result) {
	int width = image.cols;
	int height = image.rows;
	// �������ݶ�  
	float n = 0, s = 0, e = 0, w = 0;
	// ������ϵ��  
	float nc = 0, sc = 0, ec = 0, wc = 0;

	float k2 = k*k;
	float lambda2 = 0.25;
	for (int row = 1; row < height - 1; row++) {
		for (int col = 1; col < width - 1; col++) {
			// gradient  
			n = image.at<float>(row - 1, col) - image.at<float>(row, col);
			s = image.at<float>(row + 1, col) - image.at<float>(row, col);
			e = image.at<float>(row, col - 1) - image.at<float>(row, col);
			w = image.at<float>(row, col + 1) - image.at<float>(row, col);
			nc = exp(-n*n / k2);
			sc = exp(-s*s / k2);
			ec = exp(-e*e / k2);
			wc = exp(-w*w / k2);
			result.at<float>(row, col) = image.at<float>(row, col) + lambda2*(n*nc + s*sc + e*ec + w*wc);
		}
	}
}

